const fs = require('fs-extra')

exports.pbot = (pbot) => {
    return `
    Saya disini, *_BOT AKTIF_*
    
    `}